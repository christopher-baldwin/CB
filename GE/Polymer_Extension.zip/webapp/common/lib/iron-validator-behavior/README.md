# iron-validator-behavior
Use `Polymer.IronValidatorBehavior` to implement a custom input/form validator. Element instances
implementing this behavior will be registered for use in elements that implement
`Polymer.IronValidatableBehavior`.
