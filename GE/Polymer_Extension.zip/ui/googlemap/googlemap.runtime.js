﻿(function () {
    TW.Runtime.Widgets.googlemap = function () {
        var thisWidget = this;

        this.renderHtml = function () {
            var html = '';
            html +=
                '<div class="widget-content widget-googlemap">'
                + '</div>';
            return html;
        };

        this.renderStyles = function () {
            return '';
        };

        this.afterRender = function () {
            $(window).on('polymer.ready', loadElement);
            if(window.hasOwnProperty('Polymer')){
                loadElement();
            }
        };

        function loadElement(){
            Polymer.Base.importHref( '/Thingworx/extensions/lib/google-map/google-map.html', renderElement);
        }

        function renderElement(){
            thisWidget.jqElement.append('<google-map latitude="37.77493" longitude="-122.41942">'+'</google-map>');
        }

        this.beforeDestroy = function () {
            try {
                thisWidget.jqElement.unbind();
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.polymer.beforeDestroy', err);
            }
        };

    };
}());
