﻿TW.IDE.Widgets.googlemap = function () {
    var thisWidget = this;
    this.widgetProperties = function () {
        return {
            'name': 'google-map',
            'description': 'Sample widget to load the google map polymer element',
            'properties': {
                'Width': {
                    'baseType': 'NUMBER',
                    'defaultValue': 200
                },
                'Height': {
                    'baseType': 'NUMBER',
                    'defaultValue': 200
                }
            }
        };
    };



    this.renderHtml = function () {
        var html = '';
        html +=
            '<div class="widget-content widget-googlemap">'
          + '</div>';
        return html;
    };

    this.afterRender = function () {
        $(window).on('polymer.ready', loadElement);
        if(window.hasOwnProperty('Polymer')){
            loadElement();
        }
        thisWidget.jqElement.parent().css('width', thisWidget.getProperty('Width'));
    };

    this.afterSetProperty = function (name, value) {
        switch (name) {
            case 'Width' :
                thisWidget.jqElement.parent().css('width',value);
                break;
            default:
                break;
        }
    };

    function loadElement(){
        Polymer.Base.importHref( '/Thingworx/extensions/lib/google-map/google-map.html', renderElement);
    }

    function renderElement(){
        thisWidget.jqElement.append('<google-map disable-zoom latitude="37.77493" longitude="-122.41942">'+'</google-map>');
        thisWidget.jqElement.parent().css('position','');
    }
};
