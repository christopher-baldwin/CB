(function(){
    // Check if polymer is loaded, if not load it and notify all widgets that they can start using it
    if(!polymerIsLoaded()){
        loadHtml("/Thingworx/extensions/lib/polymer/polymer.html");
    }else{
        notifyElements();
    }

    function polymerIsLoaded(){
        return window.hasOwnProperty('Polymer');
    }

    function loadHtml(url){
        var ss = document.createElement("link");
        ss.type = "text/html";
        ss.rel = "import";
        ss.href = url;
        $('head').append(ss);
        ss.addEventListener('load', function(e) {
            notifyElements();
        });
    }

    function notifyElements(){
        $(window).trigger('polymer.ready');
    }

})();
