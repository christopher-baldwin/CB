﻿TW.IDE.Widgets.goldelements = function () {
    var thisWidget = this;
    this.widgetProperties = function () {
        return {
            'name': 'GoldElements',
            'description': 'Sample widget to load different elements',
            'properties': {
                'Width': {
                    'baseType': 'NUMBER',
                    'defaultValue': 280
                },
                'Height': {
                    'baseType': 'NUMBER',
                    'defaultValue': 55
                },
                'InputType': {
                    'description': 'The polymer element type to use for this widget',
                    'baseType': 'STRING',
                    'defaultValue': 'gold-phone-input',
                    'selectOptions': [
                        { value: 'gold-cc-cvc-input', text: 'CC CVC input' },
                        { value: 'gold-cc-expiration-input', text: 'CC expiration input' },
                        { value: 'gold-cc-input', text: 'CC input' },
                        { value: 'gold-email-input', text: 'email input' },
                        { value: 'gold-phone-input', text: 'phone input' },
                        { value: 'gold-zip-input', text: 'zip input' }
                    ]
                }
            }
        };
    };



    this.renderHtml = function () {
        var html = '';
        html +=
            '<div class="widget-content widget-goldelements">'
          + '</div>';
        return html;
    };

    this.afterRender = function () {
        $(window).on('polymer.ready', loadElement);
        if(window.hasOwnProperty('Polymer')){
            loadElement();
        }
        thisWidget.jqElement.parent().css('width', thisWidget.getProperty('Width'));
    };

    this.afterSetProperty = function (name, value) {
        switch (name) {
            case 'InputType' :
                clearElement();
                loadElement();
                break;
            case 'Width' :
                thisWidget.jqElement.parent().css('width',value);
                break;
            default:
                break;
        }
    };


    function loadElement(){
        var inputType = thisWidget.getProperty('InputType');
        Polymer.Base.importHref( '/Thingworx/extensions/lib/'+inputType+'/'+inputType+'.html', renderElement);
    }

    function renderElement(){
        var inputType = thisWidget.getProperty('InputType');
        thisWidget.jqElement.append('<'+inputType+'>'+'</'+inputType+'>');
        thisWidget.jqElement.parent().css('position','');
    }

    function clearElement(){
        thisWidget.jqElement.empty();
    }

};
