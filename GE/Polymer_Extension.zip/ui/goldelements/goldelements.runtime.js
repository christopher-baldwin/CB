﻿(function () {
    TW.Runtime.Widgets.goldelements = function () {
        var thisWidget = this;
        var inputType;

        this.renderHtml = function () {
            var html = '';
            html +=
                '<div class="widget-content widget-goldelements">'
                + '</div>';
            return html;
        };

        this.renderStyles = function () {
            return '';
        };

        this.afterRender = function () {
            inputType = thisWidget.getProperty('InputType');
            $(window).on('polymer.ready', loadElement);
            if(window.hasOwnProperty('Polymer')){
                loadElement();
            }
        };

        function loadElement(){
            Polymer.Base.importHref( '/Thingworx/extensions/lib/'+inputType+'/'+inputType+'.html', renderElement);
        }

        function renderElement(){
            thisWidget.jqElement.append('<'+inputType+'>'+'</'+inputType+'>');
        }

        this.beforeDestroy = function () {
            try {
                thisWidget.jqElement.unbind();
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.goldelements.beforeDestroy', err);
            }
        };

    };
}());
