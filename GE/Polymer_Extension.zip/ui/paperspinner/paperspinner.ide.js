﻿TW.IDE.Widgets.paperspinner = function () {
    var thisWidget = this;
    this.widgetProperties = function () {
        return {
            'name': 'paper-spinner',
            'description': 'Sample widget to load the paper-spinner polymer element',
            'iconImage': 'polymer.ide.png',
            'properties': {
                'Width': {
                    'baseType': 'NUMBER',
                    'defaultValue': 30
                },
                'Height': {
                    'baseType': 'NUMBER',
                    'defaultValue': 30
                }
            }
        };
    };

    this.widgetServices = function () {
        return {
            'Toggle': { 'warnIfNotBound': false }
        };
    };


    this.renderHtml = function () {
        var html = '';
        html +=
            '<div class="widget-content widget-paperspinner">'
                + '<paper-spinner active>'+'</paper-spinner>'
            + '</div>';
        return html;
    };

    this.afterRender = function () {
        $(window).on('polymer.ready', loadElement);
        if(window.hasOwnProperty('Polymer')){
            loadElement();
        }
        thisWidget.jqElement.parent().css('width', thisWidget.getProperty('Width'));
    };

    this.afterSetProperty = function (name, value) {
        switch (name) {
            case 'Width' :
                thisWidget.jqElement.parent().css('width',value);
                break;
            default:
                break;
        }
    };


    function loadElement(){
        Polymer.Base.importHref( '/Thingworx/extensions/lib/paper-spinner/paper-spinner.html');
    }

};
