﻿(function () {
    TW.Runtime.Widgets.paperspinner = function () {
        var thisWidget = this;
        var paperElem;

        this.renderHtml = function () {
            var html = '';
            html +=
                '<div class="widget-content widget-paperspinner">'
                    + '<paper-spinner active>'+'</paper-spinner>'
                + '</div>';
            return html;
        };

        this.serviceInvoked = function (serviceName) {
            if (serviceName === 'Toggle') {
                this.toggleSpinner();
            } else {
                TW.log.error('paperspinner widget, unexpected serviceName invoked "' + serviceName + '"');
            }
        };

        this.toggleSpinner = function(){
            if(paperElem.attr('active') === ''){
                paperElem.attr('active',null);
            }else{
                paperElem.attr('active','');
            }
        };

        this.renderStyles = function () {
            return '';
        };

        this.afterRender = function () {
            paperElem = thisWidget.jqElement.find('paper-spinner');
            $(window).on('polymer.ready', loadElement);
            if(window.hasOwnProperty('Polymer')){
                loadElement();
            }
        };

        function loadElement(){
            Polymer.Base.importHref( '/Thingworx/extensions/lib/paper-spinner/paper-spinner.html');
        }

        this.beforeDestroy = function () {
            try {
                thisWidget.jqElement.unbind();
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.polymer.beforeDestroy', err);
            }
        };

    };
}());
